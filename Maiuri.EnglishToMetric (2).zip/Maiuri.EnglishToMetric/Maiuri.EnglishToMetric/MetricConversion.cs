﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Maiuri.EnglishToMetric
{
    public class MetricConversion
    {
        public int kilometers;
        public int meters;
        public double centimeters;
        private int convertedMeters;
        private double convertedCentimeters;
        private double inches;
        private int feet;
        private int yards;
        private int miles;

        public MetricConversion(String km, String me, String cm)
        {
            kilometers = Convert.ToInt32(km);
            meters = Convert.ToInt32(me);
            centimeters = Convert.ToDouble(cm);

            kilometersToMeters();
            totalAmountOfMeters();
            metersToCentimeters();
            totalAmountOfCentimeters();
            inchesTocentimeters();
            inchesToMiles();
            getRemainingCInchesFromMiles();
            inchesToYards();
            getRemainingCInchesFromYards();
            inchesToFeet();
            getRemainingCInchesFromFeet();
        }

        private int kilometersToMeters()
        {
            convertedMeters = kilometers * 1000;

            return convertedMeters;
        }

        private int totalAmountOfMeters()
        {
            meters = convertedMeters + meters;

            return meters;
        }

        private double metersToCentimeters()
        {
            double temp = Convert.ToDouble(meters);
            convertedCentimeters = temp * 100;

            return convertedCentimeters;
        }

        private double totalAmountOfCentimeters()
        {
            centimeters = convertedCentimeters + centimeters;

            return centimeters;
        }

        private double inchesTocentimeters()
        {
            inches = centimeters / 2.54;

            return inches;
        }

        private int inchesToMiles()
        {
            double temp = inches / 63360;
            miles = (int)temp / 1;

            return miles;
        }

        private double getRemainingCInchesFromMiles()
        {
            inches = inches - (miles * 63360);

            return inches;
        }

        private int inchesToYards()
        {
            double temp = inches / 36;
            yards = (int)temp / 1;

            return yards;
        }

        private double getRemainingCInchesFromYards()
        {
            inches = inches - (yards * 36);

            return inches;
        }

        private int inchesToFeet()
        {
            double temp = inches / 12;
            feet = (int)temp / 1;

            return feet;
        }

        private double getRemainingCInchesFromFeet()
        {
            inches = inches - (feet * 12);

            return inches;
        }

        public String getMiles()
        {
            return miles.ToString();
        }

        public String getYards()
        {
            return yards.ToString();
        }

        public String getFeet()
        {
            return feet.ToString();
        }

        public String getInches()
        {
            double temp = inches * 10;
            temp = (int)temp / 1;
            temp = temp * .1;

            return temp.ToString();
        }
    }
}