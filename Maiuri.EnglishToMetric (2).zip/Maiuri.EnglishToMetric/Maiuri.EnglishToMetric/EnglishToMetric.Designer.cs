﻿namespace Maiuri.EnglishToMetric
{
    partial class EnglishToMetric
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblEnglishToMetric = new System.Windows.Forms.Label();
            this.txtMiles = new System.Windows.Forms.TextBox();
            this.txtYards = new System.Windows.Forms.TextBox();
            this.txtFeet = new System.Windows.Forms.TextBox();
            this.txtInches = new System.Windows.Forms.TextBox();
            this.txtKilo = new System.Windows.Forms.TextBox();
            this.txtMeter = new System.Windows.Forms.TextBox();
            this.txtCenti = new System.Windows.Forms.TextBox();
            this.lblMiles = new System.Windows.Forms.Label();
            this.lblYards = new System.Windows.Forms.Label();
            this.lblFeet = new System.Windows.Forms.Label();
            this.lblInches = new System.Windows.Forms.Label();
            this.lblKilo = new System.Windows.Forms.Label();
            this.lblMeters = new System.Windows.Forms.Label();
            this.lblCenti = new System.Windows.Forms.Label();
            this.btnEnter = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.optEnglish = new System.Windows.Forms.RadioButton();
            this.optMetric = new System.Windows.Forms.RadioButton();
            this.grpSelectConversion = new System.Windows.Forms.GroupBox();
            this.grpSelectConversion.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblEnglishToMetric
            // 
            this.lblEnglishToMetric.AutoSize = true;
            this.lblEnglishToMetric.Font = new System.Drawing.Font("Microsoft Sans Serif", 32F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEnglishToMetric.Location = new System.Drawing.Point(177, 9);
            this.lblEnglishToMetric.Name = "lblEnglishToMetric";
            this.lblEnglishToMetric.Size = new System.Drawing.Size(427, 63);
            this.lblEnglishToMetric.TabIndex = 0;
            this.lblEnglishToMetric.Text = "English to Metric";
            // 
            // txtMiles
            // 
            this.txtMiles.Location = new System.Drawing.Point(225, 140);
            this.txtMiles.Name = "txtMiles";
            this.txtMiles.Size = new System.Drawing.Size(100, 22);
            this.txtMiles.TabIndex = 1;
            // 
            // txtYards
            // 
            this.txtYards.Location = new System.Drawing.Point(225, 169);
            this.txtYards.Name = "txtYards";
            this.txtYards.Size = new System.Drawing.Size(100, 22);
            this.txtYards.TabIndex = 2;
            // 
            // txtFeet
            // 
            this.txtFeet.Location = new System.Drawing.Point(225, 198);
            this.txtFeet.Name = "txtFeet";
            this.txtFeet.Size = new System.Drawing.Size(100, 22);
            this.txtFeet.TabIndex = 3;
            // 
            // txtInches
            // 
            this.txtInches.Location = new System.Drawing.Point(225, 227);
            this.txtInches.Name = "txtInches";
            this.txtInches.Size = new System.Drawing.Size(100, 22);
            this.txtInches.TabIndex = 4;
            // 
            // txtKilo
            // 
            this.txtKilo.Location = new System.Drawing.Point(471, 139);
            this.txtKilo.Name = "txtKilo";
            this.txtKilo.Size = new System.Drawing.Size(100, 22);
            this.txtKilo.TabIndex = 5;
            // 
            // txtMeter
            // 
            this.txtMeter.Location = new System.Drawing.Point(471, 168);
            this.txtMeter.Name = "txtMeter";
            this.txtMeter.Size = new System.Drawing.Size(100, 22);
            this.txtMeter.TabIndex = 6;
            // 
            // txtCenti
            // 
            this.txtCenti.Location = new System.Drawing.Point(471, 197);
            this.txtCenti.Name = "txtCenti";
            this.txtCenti.Size = new System.Drawing.Size(100, 22);
            this.txtCenti.TabIndex = 7;
            // 
            // lblMiles
            // 
            this.lblMiles.AutoSize = true;
            this.lblMiles.Location = new System.Drawing.Point(170, 142);
            this.lblMiles.Name = "lblMiles";
            this.lblMiles.Size = new System.Drawing.Size(40, 17);
            this.lblMiles.TabIndex = 8;
            this.lblMiles.Text = "Miles";
            // 
            // lblYards
            // 
            this.lblYards.AutoSize = true;
            this.lblYards.Location = new System.Drawing.Point(170, 174);
            this.lblYards.Name = "lblYards";
            this.lblYards.Size = new System.Drawing.Size(45, 17);
            this.lblYards.TabIndex = 9;
            this.lblYards.Text = "Yards";
            // 
            // lblFeet
            // 
            this.lblFeet.AutoSize = true;
            this.lblFeet.Location = new System.Drawing.Point(170, 200);
            this.lblFeet.Name = "lblFeet";
            this.lblFeet.Size = new System.Drawing.Size(36, 17);
            this.lblFeet.TabIndex = 10;
            this.lblFeet.Text = "Feet";
            // 
            // lblInches
            // 
            this.lblInches.AutoSize = true;
            this.lblInches.Location = new System.Drawing.Point(170, 227);
            this.lblInches.Name = "lblInches";
            this.lblInches.Size = new System.Drawing.Size(49, 17);
            this.lblInches.TabIndex = 11;
            this.lblInches.Text = "Inches";
            // 
            // lblKilo
            // 
            this.lblKilo.AutoSize = true;
            this.lblKilo.Location = new System.Drawing.Point(578, 140);
            this.lblKilo.Name = "lblKilo";
            this.lblKilo.Size = new System.Drawing.Size(74, 17);
            this.lblKilo.TabIndex = 12;
            this.lblKilo.Text = "Kilometers";
            // 
            // lblMeters
            // 
            this.lblMeters.AutoSize = true;
            this.lblMeters.Location = new System.Drawing.Point(581, 168);
            this.lblMeters.Name = "lblMeters";
            this.lblMeters.Size = new System.Drawing.Size(51, 17);
            this.lblMeters.TabIndex = 13;
            this.lblMeters.Text = "Meters";
            // 
            // lblCenti
            // 
            this.lblCenti.AutoSize = true;
            this.lblCenti.Location = new System.Drawing.Point(581, 202);
            this.lblCenti.Name = "lblCenti";
            this.lblCenti.Size = new System.Drawing.Size(83, 17);
            this.lblCenti.TabIndex = 14;
            this.lblCenti.Text = "Centimeters";
            // 
            // btnEnter
            // 
            this.btnEnter.Location = new System.Drawing.Point(359, 316);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(75, 23);
            this.btnEnter.TabIndex = 15;
            this.btnEnter.Text = "Enter";
            this.btnEnter.UseVisualStyleBackColor = true;
            this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(220, 316);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 16;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(495, 315);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 17;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // optEnglish
            // 
            this.optEnglish.AutoSize = true;
            this.optEnglish.Location = new System.Drawing.Point(32, 21);
            this.optEnglish.Name = "optEnglish";
            this.optEnglish.Size = new System.Drawing.Size(75, 21);
            this.optEnglish.TabIndex = 18;
            this.optEnglish.TabStop = true;
            this.optEnglish.Text = "English";
            this.optEnglish.UseVisualStyleBackColor = true;
            this.optEnglish.CheckedChanged += new System.EventHandler(this.optEnglish_CheckedChanged);
            // 
            // optMetric
            // 
            this.optMetric.AutoSize = true;
            this.optMetric.Location = new System.Drawing.Point(281, 21);
            this.optMetric.Name = "optMetric";
            this.optMetric.Size = new System.Drawing.Size(67, 21);
            this.optMetric.TabIndex = 19;
            this.optMetric.TabStop = true;
            this.optMetric.Text = "Metric";
            this.optMetric.UseVisualStyleBackColor = true;
            this.optMetric.CheckedChanged += new System.EventHandler(this.optMetric_CheckedChanged);
            // 
            // grpSelectConversion
            // 
            this.grpSelectConversion.Controls.Add(this.optMetric);
            this.grpSelectConversion.Controls.Add(this.optEnglish);
            this.grpSelectConversion.Location = new System.Drawing.Point(188, 75);
            this.grpSelectConversion.Name = "grpSelectConversion";
            this.grpSelectConversion.Size = new System.Drawing.Size(391, 51);
            this.grpSelectConversion.TabIndex = 20;
            this.grpSelectConversion.TabStop = false;
            this.grpSelectConversion.Text = "Select Conversion Type";
            // 
            // EnglishToMetric
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.grpSelectConversion);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnEnter);
            this.Controls.Add(this.lblCenti);
            this.Controls.Add(this.lblMeters);
            this.Controls.Add(this.lblKilo);
            this.Controls.Add(this.lblInches);
            this.Controls.Add(this.lblFeet);
            this.Controls.Add(this.lblYards);
            this.Controls.Add(this.lblMiles);
            this.Controls.Add(this.txtCenti);
            this.Controls.Add(this.txtMeter);
            this.Controls.Add(this.txtKilo);
            this.Controls.Add(this.txtInches);
            this.Controls.Add(this.txtFeet);
            this.Controls.Add(this.txtYards);
            this.Controls.Add(this.txtMiles);
            this.Controls.Add(this.lblEnglishToMetric);
            this.Name = "EnglishToMetric";
            this.Text = "English to Metric";
            this.Load += new System.EventHandler(this.EnglishToMetric_Load);
            this.grpSelectConversion.ResumeLayout(false);
            this.grpSelectConversion.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblEnglishToMetric;
        private System.Windows.Forms.TextBox txtMiles;
        private System.Windows.Forms.TextBox txtYards;
        private System.Windows.Forms.TextBox txtFeet;
        private System.Windows.Forms.TextBox txtInches;
        private System.Windows.Forms.TextBox txtKilo;
        private System.Windows.Forms.TextBox txtMeter;
        private System.Windows.Forms.TextBox txtCenti;
        private System.Windows.Forms.Label lblMiles;
        private System.Windows.Forms.Label lblYards;
        private System.Windows.Forms.Label lblFeet;
        private System.Windows.Forms.Label lblInches;
        private System.Windows.Forms.Label lblKilo;
        private System.Windows.Forms.Label lblMeters;
        private System.Windows.Forms.Label lblCenti;
        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.RadioButton optEnglish;
        private System.Windows.Forms.RadioButton optMetric;
        private System.Windows.Forms.GroupBox grpSelectConversion;
    }
}

