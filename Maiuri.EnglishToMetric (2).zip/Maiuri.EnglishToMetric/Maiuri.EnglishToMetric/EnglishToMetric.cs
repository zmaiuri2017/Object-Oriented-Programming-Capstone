﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maiuri.EnglishToMetric
{
    public partial class EnglishToMetric : Form
    {
        public EnglishToMetric()
        {
            InitializeComponent();
        }

        private void EnglishToMetric_Load(object sender, EventArgs e)
        {
            optEnglish.Checked = true;
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            NumberValidation valid = new NumberValidation();

            if (optEnglish.Checked == true)
            {
                if (valid.validateIntNumber(txtMiles.Text) && valid.validateIntNumber(txtYards.Text) && valid.validateIntNumber(txtFeet.Text) && valid.validateDoubleNumber(txtInches.Text))
                {
                    EnglishConversion ec = new EnglishConversion(txtMiles.Text, txtYards.Text, txtFeet.Text, txtInches.Text);

                    txtKilo.Text = ec.getKilometers();
                    txtMeter.Text = ec.getMeters();
                    txtCenti.Text = ec.getCentimeters();
                }
            }
            else if (optMetric.Checked == true)
            {
                if (valid.validateIntNumber(txtKilo.Text) && valid.validateIntNumber(txtMeter.Text) && valid.validateDoubleNumber(txtCenti.Text))
                {
                    MetricConversion mc = new MetricConversion(txtKilo.Text, txtMeter.Text, txtCenti.Text);

                    txtMiles.Text = mc.getMiles();
                    txtYards.Text = mc.getYards();
                    txtFeet.Text = mc.getFeet();
                    txtInches.Text = mc.getInches();
                }
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtMiles.Clear();
            txtYards.Clear();
            txtFeet.Clear();
            txtInches.Clear();
            txtKilo.Clear();
            txtMeter.Clear();
            txtCenti.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void optEnglish_CheckedChanged(object sender, EventArgs e)
        {
            txtMiles.Enabled = true;
            txtYards.Enabled = true;
            txtFeet.Enabled = true;
            txtInches.Enabled = true;
            txtKilo.Enabled = false;
            txtMeter.Enabled = false;
            txtCenti.Enabled = false;
        }

        private void optMetric_CheckedChanged(object sender, EventArgs e)
        {
            txtMiles.Enabled = false;
            txtYards.Enabled = false;
            txtFeet.Enabled = false;
            txtInches.Enabled = false;
            txtKilo.Enabled = true;
            txtMeter.Enabled = true;
            txtCenti.Enabled = true;
        }
    }
}
