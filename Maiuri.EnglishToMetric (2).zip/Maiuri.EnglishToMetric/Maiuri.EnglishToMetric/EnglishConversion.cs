﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Maiuri.EnglishToMetric
{
    public class EnglishConversion
    {
        public int miles;
        public int yards;
        public int feet;
        public double inches;
        private int convertedYards;
        private int convertedFeet;
        private double convertedInches;
        private double centimeters;
        private int meters;
        private int kilometers;

        public EnglishConversion(String m, String y, String f, String inc)
        {
            miles = Convert.ToInt32(m);
            yards = Convert.ToInt32(y);
            feet = Convert.ToInt32(f);
            inches = Convert.ToDouble(inc);

            milesToYards();
            totalAmountOfYards();
            yardsToFeet();
            totalAmountOfFeet();
            feetToinches();
            totalAmountOfInches();
            inchesTocentimeters();
            centimeterToKilometers();
            getRemainingCentimetersFromKilometers();
            centimeterToMeters();
            getRemainingCentimetersFromMeters();
        }

        private int milesToYards()
        {
            convertedYards = miles * 1760;

            return convertedYards;
        }

        private int totalAmountOfYards()
        {
            yards = convertedYards + yards;

            return yards;
        }

        private int yardsToFeet()
        {
            convertedFeet = yards * 3;

            return convertedFeet;
        }

        private int totalAmountOfFeet()
        {
            feet = convertedFeet + feet;

            return feet;
        }

        private double feetToinches()
        {
            double temp = Convert.ToDouble(feet);
            convertedInches = temp * 12;

            return convertedInches;
        }

        private double totalAmountOfInches()
        {
            inches = convertedInches + inches;

            return inches;
        }

        private double inchesTocentimeters()
        {
            centimeters = inches * 2.54;

            return centimeters;
        }

        private int centimeterToKilometers()
        {
            double temp = centimeters / 100000;
            kilometers = (int)temp / 1;

            return kilometers;
        }

        private double getRemainingCentimetersFromKilometers()
        {
            centimeters = centimeters - (kilometers * 100000);

            return centimeters;
        }

        private int centimeterToMeters()
        {
            double temp = centimeters / 100;
            meters = (int)temp / 1;

            return meters;
        }

        private double getRemainingCentimetersFromMeters()
        {
            centimeters = centimeters - (meters * 100);

            return centimeters;
        }

        public String getCentimeters()
        {
            double temp = centimeters * 10;
            temp = (int)temp / 1;
            temp = temp * .1;

            return temp.ToString();
        }

        public String getMeters()
        {
            return meters.ToString();
        }

        public String getKilometers()
        {
            return kilometers.ToString();
        }
    }
}