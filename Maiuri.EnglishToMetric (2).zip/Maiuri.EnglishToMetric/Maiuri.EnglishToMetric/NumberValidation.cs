﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Maiuri.EnglishToMetric
{
    public class NumberValidation
    {
        public NumberValidation()
        {
            
        }

       public bool validateIntNumber(String temp)
        {
            try
            {
                Convert.ToInt32(temp);
                if (Convert.ToInt32(temp) > -1)
                {
                    return true;
                }
            }
            catch
            {
                return false;
            }
            return true;
        }

        public bool validateDoubleNumber(String temp)
        {
            try
            {
                Convert.ToDouble(temp);
                if (Convert.ToDouble(temp) >= 0)
                {
                    int period = findDecimalPlace(temp);
                    if (period == -1)
                    {
                        return true;
                    }
                    else
                    {
                        return checkForSingleNumberPlace(temp, period);
                    }
                }
            }
            catch
            {
                return false;
            }
            return true;
        }

        public int findDecimalPlace(String temp)
        {
            for (int n = 0; n < temp.Length; n++)
            {
                if (temp[n] == '.')
                {
                    return n;
                }
            }
            return -1;
        }

        public bool checkForSingleNumberPlace(String temp, int n)
        {
            String remainder = temp.Substring(n);
            if (remainder.Length > 2)
            {
                return false;
            }

            return true;
        }
    }
}